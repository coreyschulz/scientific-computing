#### Corey Schulz
#### 2.2.20
#### CS 3200
#### SP 20


To run each included Matlab script:
   * question_1.m
   * question_2.m
   * question_3.m
   * question_4.m
...simply open the desired file in Matlab, and click 'Run' at the top of the GUI.
You should see error information appear in the Command Window.
You should see 5 plots appear for questions 1 through 3.
You should see 10 plots appear for question 4.

