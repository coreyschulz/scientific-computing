#### Corey Schulz
#### 4.20.20
#### CS 3200
#### SP 20


To run each included Matlab script:
   * question_1.m
   * question_2_mandrill.m
   * question_2_durer.m
...simply open the desired file in Matlab, and click 'Run' at the top of the GUI.

You should see console output and 18 graphs appear in question 1. 
You should see console output and 7 images in question 2 mandrill. 
You should see console output and 7 images in question 2 durer. 
