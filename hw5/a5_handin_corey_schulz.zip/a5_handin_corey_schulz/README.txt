#### Corey Schulz
#### 4.14.20
#### CS 3200
#### SP 20


To run each included Matlab script:
   * question_1.m
   * question_2.m
...simply open the desired file in Matlab, and click 'Run' at the top of the GUI.

You should see console output for each part in question 1. 
Should you like to see the graphs used in the report, uncomment the plotting in the power_method function and hold all in Matlab. 
You should see console output for each part in question 2. 
