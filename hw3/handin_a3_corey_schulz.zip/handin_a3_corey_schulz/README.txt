#### Corey Schulz
#### 3.15.20
#### CS 3200
#### SP 20


To run each included Matlab script:
   * question_1.m
   * question_2_part_1.m
   * question_2_part_2.m
   * question_3.m
...simply open the desired file in Matlab, and click 'Run' at the top of the GUI.

You should see LU factorizations in question 1. 
You should see 9 figures for question_2_part_1.
You should see 6 figures for question_2_part_2.
You should see console information for given SIZE for question_3.

